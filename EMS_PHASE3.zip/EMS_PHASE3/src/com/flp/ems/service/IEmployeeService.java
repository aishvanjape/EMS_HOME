package com.flp.ems.service;

import java.util.ArrayList;
import java.util.HashMap;

public interface IEmployeeService {
	
	
	String AddEmployee(HashMap<String, String> employeehashmap);
	String ModifyEmployee(HashMap<String, String> employeehashmap);
	String RemoveEmployee(HashMap<String, String> hashobject);	
	String[] SearchEmployee(HashMap<String, String> fieldhashmap);
	ArrayList<String[]> getAllEmployee();
	
}
