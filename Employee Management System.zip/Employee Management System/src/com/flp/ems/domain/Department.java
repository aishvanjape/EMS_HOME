package com.flp.ems.domain;

public class Department {

	private long Department_Id;
	private String Name;
	private String Description;
	
}
