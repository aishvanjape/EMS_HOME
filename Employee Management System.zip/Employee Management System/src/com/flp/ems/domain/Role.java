package com.flp.ems.domain;

public class Role {

	private long Role_Id;
	private String Name;
	private String Description;
	
}
