package com.flp.ems.domain;

public class Project {

	private long Project_Id;
	private String Name;
	private String Description;
	private long Department_Id;
	
}
